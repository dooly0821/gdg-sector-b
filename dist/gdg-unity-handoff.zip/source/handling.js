import {basis} from './world.js';
import {CONFIG,baySlot,deliveryCount,canUse,interact} from './mission.js';

const smooth=x=>{x=Math.max(0,Math.min(1,x));return x*x*(3-2*x);};
const mix=(a,b,t)=>a+(b-a)*t;

// Keep the exported scene intact. Split only the viewmodel's draw batches.
export function rigs(worlds){
 const [building,parcel,empty,carried]=worlds;
 const group=(world,channel)=>({materials:world.materials,parts:world.parts.filter(p=>p.channel===channel)});
 return [building,parcel,group(empty,'left'),group(empty,'right'),group(carried,'left'),group(carried,'right'),group(carried,'parcel')];
}
export function beginHandling(s,target,blocks){
 if(s.handAction||!canUse(s,target,blocks))return false;
 if(target.dock?s.carried<0:s.states[target.index]!=='AVAILABLE'||s.carried>=0)return false;
 s.handAction={placing:!!target.dock,target,index:target.dock?s.carried:target.index,
  worldPos:target.dock?baySlot(deliveryCount(s)):target.pos.slice(),time:0,duration:target.dock?.84:.78};
 return true;
}
export function advanceHandling(s,blocks,dt){
 const a=s.handAction;if(!a)return null;
 if(!canUse(s,a.target,blocks)){s.handAction=null;return 'cancelled';}
 a.time+=dt;if(a.time<a.duration)return null;
 s.handAction=null;
 return interact(s,a.target,blocks);
}
function transform(angles,position,scale){
 const axes=basis(...angles);
 return new Float32Array([...axes[0].map(v=>v*scale),0,...axes[1].map(v=>v*scale),0,...axes[2].map(v=>v*scale),0,...position,1]);
}
export function choreography(s,eye,near,moving,sprinting,t){
 const a=s.handAction,phase=a?Math.min(1,a.time/a.duration):0;
 const grip=a?(a.placing?1-smooth(phase/.88):smooth((phase-.13)/.87)):Number(s.carried>=0);
 const holding=a?(a.placing?phase<.83:phase>.21):s.carried>=0;
 const stride=moving?(sprinting?1.45:1):0;
 const weight=Number(holding),wave=Math.sin(s.steps*4.7),breath=Math.sin(t*1.8)*.0035;
 const bob=[wave*.012*stride,breath+Math.sin(s.steps*9.4)*.008*stride,Math.cos(s.steps*4.7)*.009*stride];
 const reach=a?Math.sin(Math.PI*phase):0;
 const close=near&&!a&&!holding?.032:0;
 const hands=[-1,1].map((side,i)=>({
  group:(holding?4:2)+i,
  offset:[bob[0]+side*((1-weight)*wave*.012*stride-.055*reach-close),bob[1]+side*(1-weight)*wave*.023*stride-.044*reach+close*.48,bob[2]-.18*reach-close]
 }));
 if(!a&&holding)hands.push({group:6,offset:bob});
 let flight=null;
 if(a){
  const cameraAxes=basis(s.pitch,s.yaw,0),held=[bob[0],-.584+bob[1],-.864+bob[2]];
  const end=eye.map((v,i)=>v+cameraAxes.reduce((sum,axis,j)=>sum+axis[i]*held[j],0));
  const position=a.worldPos.map((v,i)=>mix(v,end[i],grip));
  position[1]+=.12*Math.sin(grip*Math.PI);
  const yaw=Math.atan2(Math.sin(s.yaw),Math.cos(s.yaw));
  flight=transform([s.pitch*grip,yaw*grip,Math.sin(grip*Math.PI)*.025],position,mix(1,.446/CONFIG.parcelWidth,grip));
 }
 return {hands,flight,hidden:a&&!a.placing?a.index:-1};
}
