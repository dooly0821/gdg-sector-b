// The camera looks down -Z. Both the parcel and the worker use metre units.
const PI = Math.PI;

export function buildParcel(w, x, y, z, size) {
  const h = size * 0.88;
  const d = size * 0.82;
  const mid = y + h / 2;
  const front = w.imageMat("parcel_original_front", "assets/package-front.webp");
  const side = w.imageMat("parcel_original_side", "assets/package-side.webp");
  const top = w.imageMat("parcel_original_lid", "assets/package-top.webp");
  const liner = w.mat("parcel_flute", "#ae8051", "cardboard");
  const crease = w.mat("parcel_crease", "#705034", "cardboard");
  const seal = w.mat("parcel_seal", "#d69a28", "paint");
  const gap = size * 0.001;
  w.box(x, mid, z, size, h, d, liner);
  w.face(x, mid, z+d/2+gap, size, h, front);
  w.face(x+size/2+gap, mid, z, d, h, side, 0, PI/2, 0);
  w.face(x-size/2-gap, mid, z, d, h, side, 0, -PI/2, 0);
  w.face(x, y+h+gap, z, size, d, top, -PI/2, 0, 0);
  // The original upper seal continues onto the unprinted reverse carton flap.
  w.box(x, mid, z-d/2-gap, size*.004, h, gap, crease);
  w.box(x, y+h*.895, z-d/2-2*gap, size*.18, h*.21, gap, seal);
  w.box(x, y-gap, z, size*.18, gap, d, seal);
}

function along(a, b) {
  const dx = b[0]-a[0], dy=b[1]-a[1], dz=b[2]-a[2];
  const length = Math.hypot(dx,dy,dz);
  return { mid: a.map((v,i)=>(v+b[i])*.5), length,
    angles: [Math.asin(dz/length), 0, Math.atan2(-dx,dy)] };
}

function softLink(w, a, b, radius, thickness, mat, extension=0) {
  const {mid,length,angles} = along(a,b);
  w.ball(...mid, radius,length*.5+extension, thickness,mat,...angles);
}

function sleeve(w, elbow, hem, wrist, m) {
  const vector = hem.map((v,i)=>v-elbow[i]);
  const point = t=>elbow.map((v,i)=>v+t*vector[i]);
  const angles=along(elbow,hem).angles;
  const cuff=(t,r,h,mat)=>w.cyl(...point(t),r,h,r*.96,mat,...angles);
  // Rolled cuffs and the narrow gold piping follow the GDG turnaround.
  softLink(w, elbow, hem, .105,.111,m.cloth,.038);
  cuff(.66,.099,.025,m.cloth);
  cuff(.715,.100,.019,m.piping);
  cuff(.82,.101,.033,m.fold);
  cuff(.91,.098,.022,m.cloth);
  cuff(.965,.093,.012,m.fold);
  const limb=along(point(.82),wrist);
  w.shape('forearm',...limb.mid,.082,limb.length+.022,.074,m.cloth,...limb.angles);
}

function emptyHand(w,s,m) {
  const v=(x,y,z)=>[s*x,y,z];
  const wrist=v(.485,-.399,-.687);
  sleeve(w,v(.716,-.505,-.474),v(.591,-.437,-.598),wrist,m);
  // Slim dorsal plane, soft knuckles and bent fingers in a relaxed half-fist.
  softLink(w,wrist,v(.447,-.354,-.744),.064,.053,m.skin,.039);
  w.ball(...v(.452,-.359,-.743),.070,.049,.067,m.skin,.06,s*.28,-s*.18);
  w.ball(...v(.451,-.329,-.726),.058,.015,.047,m.pad,.08,s*.2,-s*.18);
  for (let i=0;i<4;i++) {
    const spread=(i-1.5)*.0295;
    const drop=[0,.001,.005,.014][i];
    const x=.439+spread*.83, z=-.770-spread*.56;
    const base=v(x,-.358-drop,z);
    const knuckle=v(x-.029,-.355-drop,z-.027+drop*.65);
    const fingertip=v(x-.040,-.380-drop,z-.019+drop);
    const rad=.0180-i*.00060;
    softLink(w,base,knuckle,rad,rad,m.grip,rad*.72);
    softLink(w,knuckle,fingertip,rad*.94,rad*.94,m.grip,rad*.75);
  }
  const thumbBase=v(.427,-.367,-.723);
  const thumbJoint=v(.385,-.379,-.730);
  const thumbTip=v(.375,-.388,-.756);
  softLink(w,thumbBase,thumbJoint,.026,.026,m.skin,.017);
  softLink(w,thumbJoint,thumbTip,.021,.021,m.grip,.014);
}

function holdingHand(w,s,m,half,front) {
  const v=(x,y,z)=>[s*x,y,z];
  // Each palm cups a lower corner. The fingers curl under the side and the
  // thumbs wrap onto the nearer face so the parcel reads as weight-bearing.
  const wrist=v(.293,-.451,front+.057);
  sleeve(w,v(.580,-.485,-.320),v(.444,-.411,-.519),wrist,m);
  const palmBase=v(half+.043,-.450,front+.033);
  const palmTop=v(half+.033,-.380,front-.025);
  softLink(w,wrist,palmBase,.056,.048,m.skin,.038);
  softLink(w,palmBase,palmTop,.050,.043,m.skin,.028);
  for (let i=0;i<4;i++) {
    const yy=-.393-.027*i;
    const root=v(half+.037,yy,front-.013-i*.002);
    const mid=v(half+.036,yy-.003,front-.058-i*.002);
    const tip=v(half+.012,yy+.007,front-.086+i*.003);
    const radius=.0174-i*.00065;
    softLink(w,root,mid,radius,radius,m.grip,radius*.65);
    softLink(w,mid,tip,radius*.94,radius*.96,m.grip,radius*.67);
  }
  const thumbRoot=v(half+.035,-.397,front+.009);
  const thumbBend=v(half+.003,-.367,front+.022);
  const thumbTip=v(half-.040,-.359,front+.014);
  softLink(w,thumbRoot,thumbBend,.026,.023,m.skin,.012);
  softLink(w,thumbBend,thumbTip,.022,.018,m.grip,.014);
  // A warm low-contrast nail marks the thumbnail plane without a hard outline.
  w.ball(...v(half-.035,-.358,front+.029),.013,.009,.0034,m.nail,0,s*.22,-s*.13);
}

export function buildHands(w, carrying) {
  const m={
    cloth:w.mat("gdg_uniform_plum","#54436d","cloth"),
    fold:w.mat("gdg_uniform_cuff","#413550","cloth"),
    piping:w.mat("gdg_uniform_stitch","#e9b943","cloth"),
    skin:w.mat("gdg_glove_canvas","#bd9b6b","cloth"),
    grip:w.mat("gdg_glove_grip","#55494a","rubber"),
    pad:w.mat("gdg_glove_patch","#655365","cloth"),
    nail:w.mat("gdg_thumb_pad","#67595a","rubber")
  };
  if (carrying) {
    const width=.446, z=-.864;
    buildParcel(w,0,-.610,z,width);
    const front=z+width*.82/2;
    for(const part of w.parts)part.channel='parcel';
    for (const sign of [-1,1]) holdingHand(w,sign,m,width/2,front);
  } else {
    for (const sign of [-1,1]) emptyHand(w,sign,m);
  }
  for(const part of w.parts){
    part.pos[1]+=carrying?.026:-.038;
    part.channel??=part.pos[0]<0?'left':'right';
  }
}
