import {World,unit,dot,vsub} from './world.js';
import {buildStorage} from './storage.js';
import {buildArchitecture} from './architecture.js';
import {buildMachinery} from './machinery.js';
import {stageFreight} from './freight.js';
import {buildHands,buildParcel} from './viewmodel.js';
export const CONFIG={eye:1.58,radius:.255,height:1.70,walk:2.75,sprint:4.65,gravity:13.5,jump:4.75,reach:2.75,fov:78,pitchLimit:1.30,spawn:[1.7,0,15],sensitivity:.0021,parcelWidth:.55};
export const PARCELS=[
 {id:'B-01',area:'Employee intake',pos:[.8,.72,12.75]},
 {id:'B-02',area:'Storage cross aisle',pos:[-6.22,.72,-5.2]},
 {id:'B-03',area:'Conveyor sorting',pos:[7.15,1.072,2.4]},
 {id:'B-04',area:'Upper catwalk',pos:[13.90,4.32,-4.45]},
 {id:'B-05',area:'Loading aisle',pos:[-7.75,.72,-13.4]}];
export const DOCK=[4.6,.24,-19.6];
export function createScene(){
 const w=new World();buildArchitecture(w);buildStorage(w);buildMachinery(w);stageFreight(w);
 const steel=w.mat('dispatch-steel','#566168','metal'),edge=w.mat('bench-edge','#a58a53','paint'),plank=w.mat('dispatch-pine','#a58462','wood');
 const black=w.mat('bay-charcoal','#4b4b46','paint'),amber=w.mat('amber-traffic-paint','#c59a43','paint');
 for(const p of PARCELS.filter(p=>p.id!=='B-03')){
  const [x,y,z]=p.pos,base=y-.72;
  for(let side of [-1,1])for(let end of [-1,1])w.box(x+side*.43,base+.33,z+end*.31,.055,.66,.055,steel);
  w.box(x,y-.048,z,1.03,.096,.79,plank);w.box(x,y-.13,z+.33,1.0,.12,.045,edge);
  w.block(x-.51,z-.4,x+.51,z+.4,base,y);
 }
 const [x,y,z]=DOCK;
 for(let dx of [-1,0,1])w.box(x+dx,.092,z,.13,.184,1.6,plank);
 for(let i=0;i<9;i++)w.box(x+(i-4)*.283,.208,z,.266,.064,1.6,plank);
 w.block(x-1.27,z-.8,x+1.27,z+.8,0,.27);
 for(const dx of [-1.52,1.52])w.box(x+dx,.009,z,.09,.015,1.95,amber);
 for(const dz of [-.98,.98])w.box(x,.009,z+dz,3.12,.015,.09,amber);
 for(const dx of [-1.65,1.65]){w.box(x+dx,.82,z-1,.07,1.64,.07,steel);w.box(x+dx,.08,z-1,.21,.16,.21,black);}
 w.box(x,1.72,z-1,3.46,.55,.1,black);w.sign(x,1.71,z-.94,3.32,.45,'DISPATCH   /   BAY 02','#b08837','#171b17');
 const parcel=new World(),empty=new World(),carry=new World();buildParcel(parcel,0,0,0,CONFIG.parcelWidth);buildHands(empty,false);buildHands(carry,true);
 return [w,parcel,empty,carry];
}
export function newShift(){return {x:1.7,y:0,z:15,yaw:.24,pitch:-.04,vy:0,grounded:true,states:PARCELS.map(()=> 'AVAILABLE'),carried:-1,elapsed:0,steps:0};}
export const deliveryCount=s=>s.states.filter(k=>k==='DELIVERED').length;
export const forward=s=>[-Math.sin(s.yaw)*Math.cos(s.pitch),Math.sin(s.pitch),-Math.cos(s.yaw)*Math.cos(s.pitch)];
export function surface(x,z,y){
 if(x>11.64&&x<13.36&&z<15.13&&z>=6.94){const top=Math.min(3.6,Math.max(0,(15-z)*.45));return y+.32>=top?top:0;}
 if(x>=11&&x<=14.9&&z>=-20&&z<=7.08&&y>=3.25)return 3.6;
 return 0;
}
export function step(s,keys,blocks,dt,jump=false){
 const {radius,walk,sprint,height,gravity}=CONFIG,up=(keys.has('KeyW')?1:0)-(keys.has('KeyS')?1:0),side=(keys.has('KeyD')?1:0)-(keys.has('KeyA')?1:0);
 const mag=Math.hypot(side,up),distance=dt*((keys.has('ShiftLeft')||keys.has('ShiftRight'))?sprint:walk);
 const dx=mag?(Math.cos(s.yaw)*side-Math.sin(s.yaw)*up)*distance/mag:0,dz=mag?(-Math.sin(s.yaw)*side-Math.cos(s.yaw)*up)*distance/mag:0;
 const blocked=(x,z)=>{
  if(Math.abs(x)>14.55-radius||Math.abs(z)>21.40-radius)return true;
  const foot=Math.max(s.y,surface(x,z,s.y));
  if(x>11-radius&&z>=-20-radius&&z<=7+radius&&foot+height>3.12&&foot<3.22)return true;
  return blocks.some(([a,b,c,d,lo,hi])=>foot<hi-.025&&foot+height>lo+.025&&Math.max(a-x,0,x-c)**2+Math.max(b-z,0,z-d)**2<radius*radius);
 };
 const old=[s.x,s.z];if(!blocked(s.x+dx,s.z))s.x+=dx;if(!blocked(s.x,s.z+dz))s.z+=dz;
 s.steps+=Math.hypot(s.x-old[0],s.z-old[1]);
 if(jump&&s.grounded){s.vy=CONFIG.jump;s.grounded=false;}
 const floor=surface(s.x,s.z,s.y);
 s.vy-=gravity*dt;let next=s.y+s.vy*dt;
 if(s.vy>0&&s.x>11&&s.z>=-20&&s.z<=7&&s.y<3.0&&next+height>=3.12){next=3.12-height;s.vy=0;}
 if(next<=floor+.003||(s.grounded&&s.y-floor<.13)){s.y=floor;s.vy=0;s.grounded=true;}else{s.y=next;s.grounded=false;}
 s.elapsed+=dt;
}
export function nextTarget(s){
 if(s.carried>=0)return {pos:DOCK,id:'BAY 02',area:'Outbound dispatch',dock:true};
 let best=null,d=Infinity;for(let i=0;i<PARCELS.length;i++){if(s.states[i]!=='AVAILABLE')continue;const p=PARCELS[i];let dist=Math.hypot(s.x-p.pos[0],s.z-p.pos[2],(s.y-p.pos[1])*1.8);if(dist<d){best={...p,index:i};d=dist;}}
 return best;
}
export function canUse(s,target,blocks=[]){
 if(!target)return false;let pos=target.pos.slice();pos[1]+=target.dock?.55:.24;
 const eye=[s.x,s.y+CONFIG.eye,s.z],v=vsub(pos,eye),d=Math.hypot(...v);
 if(d>CONFIG.reach||dot(unit(v),forward(s))<.63)return false;
 // Ray segment intersects solid props. Skip the target's own support.
 for(const [x1,z1,x2,z2,y1,y2] of blocks){
  if(target.id==='B-03' && x1<pos[0]&&x2>pos[0]&&z1<pos[2]&&z2>pos[2])continue;
  let lo=0,hi=.97;
  for(const [j,a,b] of [[0,x1,x2],[1,y1,y2],[2,z1,z2]]){if(Math.abs(v[j])<.00001){if(eye[j]<a||eye[j]>b){hi=-1;break;}continue;}const t1=(a-eye[j])/v[j],t2=(b-eye[j])/v[j];lo=Math.max(lo,Math.min(t1,t2));hi=Math.min(hi,Math.max(t1,t2));}
  if(lo<hi)return false;
 }
 return true;
}
export function interact(s,target,blocks){
 if(!canUse(s,target,blocks))return null;
 if(target.dock&&s.carried>=0&&s.states[s.carried]==='CARRIED'){s.deliveryOrder??=s.states.flatMap((v,i)=>v==='DELIVERED'?[i]:[]);s.deliveryOrder.push(s.carried);s.states[s.carried]='DELIVERED';s.carried=-1;return 'delivered';}
 if(!target.dock&&s.carried===-1&&s.states[target.index]==='AVAILABLE'){s.carried=target.index;s.states[target.index]='CARRIED';return 'picked';}
 return null;
}
export function baySlot(n){return [DOCK[0]+((n%3)-1)*.65,DOCK[1],DOCK[2]+(Math.floor(n/3)-.5)*.60];}
export function parcelPositions(s,hidden=-1){
 const order=s.deliveryOrder??s.states.flatMap((v,i)=>v==='DELIVERED'?[i]:[]);
 return PARCELS.flatMap((p,i)=>i===hidden?[]:s.states[i]==='AVAILABLE'?[p.pos]:s.states[i]==='DELIVERED'?[baySlot(order.indexOf(i))]:[]);
}
